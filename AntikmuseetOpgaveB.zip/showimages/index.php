<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="da" lang="da">
<?php 
	$title = "My favourite movies";
	$sti = $_SERVER['DOCUMENT_ROOT'].'/yourfoldernamehere/Pics/small';
	$sti = "./photos"; // delete this line if your PHP 
					//  requires more specific folder id (as in line 3)
	
?>
  
<head>
    <title>Antik museet puslespils quiz</title>
    <link href="css/style.css" rel="stylesheet" />
    <link href="css/image-puzzle.css" rel="stylesheet" />
    <script src="js/jquery-2.1.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/image-puzzle.js"></script>
</head>

<body>
    <div id="collage">
        <h2>Antik museet puslespils konkurrence</h2>
        <hr />
        
        <div id="playPanel" style="padding:5px;display:none;">
        	<h3 id="imgTitle"></h3> <hr />
           	
            	<div style="display:inline-block; margin:auto; width:95%; vertical-align:top;">
                	<ul id="sortable" class="sortable"></ul>
                	<div id="actualImageBox">
                   	
                    	<div id="stepBox">
                        	<div>Antal ryk:</div><div class="stepCount">0</div>
                    	</div>
                    	
						<div id="timeBox">
							Tid: <span id="timerPanel"></span> sek
						</div>
                   
                    	<img id="actualImage" />
                    	<div>Flyt brikkerne så billedet ligner dette</div>
                    
                       
                    	
                       	
                	</div>
           		</div>
        </div>
        
        
        <div id="gameOver" style="display:none;">
        
        	<div style="background-color: white; padding: 5px 10px 20px 10px; text-align: center; ">
                <h2 style="text-align:center">Du gjorde det!</h2>
                
                Tillykke!! <br /> Tag et billede af din tid, og opload det her på siden. Så er du med i konkurrencen<br>
                <br />
                Antal ryk: <span class="stepCount">0</span> steps.
                <br />
                Tid: <span class="timeCount">0</span> sekunder<br /><br>
                <div>
                    <button type="button" onclick="window.location.reload(true);">Spil igen</button>
                </div>
            </div>
        </div>

		
		
		
		
		
        <script>
            var images = [
                { src: 'images/puzzle.jpg', title: 'Amons Tempel' },
            ];

			
            $(function () {
                var gridSize = $('#levelPanel :radio:checked').val();
                imagePuzzle.startGame(images, gridSize);
                $('#newPhoto').click(function () {
                    var gridSize = $('#levelPanel :radio:checked').val();  // Take the updated gridSize from UI.
                    imagePuzzle.startGame(images, gridSize);
                });

                $('#levelPanel :radio').change(function (e) {
                    var gridSize = $(this).val();
                    imagePuzzle.startGame(images, gridSize);
                });
            });
            function rules() {
                alert('Re arrange the image parts in a way that it correctly forms the picture. \nThe no. of steps taken will be counted.');
            }
            function about() {
                alert('Developed by Anurag Gandhi. \nHe can be contacted at: soft.gandhi@gmail.com');
            }
        </script>
    </div>

  <hr> 
    <section>
    	
    	<?php

if ( isset( $_POST["sendPhoto"] ) ) {
  processForm();
} else {
  displayForm();
}

function processForm() {
  if ( isset( $_FILES["photo"] ) and $_FILES["photo"]["error"] == UPLOAD_ERR_OK ) {
    if ( $_FILES["photo"]["type"] != "image/jpeg" ) {
      echo "<p>Kun JPEG billeder kan indsendes til konkurrencen</p>";
    } elseif ( !move_uploaded_file( $_FILES["photo"]["tmp_name"], "photos/" . basename( $_FILES["photo"]["name"] ) ) ) {
      echo "<p>Ups, der var et problem ved oploadingen af din fil</p>" . $_FILES["photo"]["error"] ;
    } else {
      displayThanks();
    }
  } else {
    switch( $_FILES["photo"]["error"] ) {
      case UPLOAD_ERR_INI_SIZE:
        $message = "Billedet er større end 5 MB.";
        break;
      case UPLOAD_ERR_FORM_SIZE:
        $message = "Billedet er større end 5 MB.";
        break;
      case UPLOAD_ERR_NO_FILE:
        $message = "Der er ikke valgt nogen fil - husk at vælge en fil før du trykker send.";
        break;
      default:
        $message = "Ups vi har et internt problem - prøv igen senere";
    }
    echo "<p>Ups, der var et problem ved oploadingen af din fil $message</p>";
  }
}

function displayForm() {
?>
    <h2>Upload dit billede her og deltag i konkurrencen</h2>

    <p>Skriv venligst dit navn her, og indsend dit billede. Så er du med i konkurrencen om at vinde en spændende bog om museets udstillinger!</p>

    <form action="index.php" method="post" enctype="multipart/form-data">
      <div>
        <input type="hidden" name="MAX_FILE_SIZE" value="5000000" />

        <label for="visitorName">Navn</label>
        <input type="text" name="visitorName" id="visitorName" value="" />
<br>
        <label for="photo">Billede</label>
        <input type="file" name="photo" id="photo" value="" />

        <div style="clear: both;">
          <input type="submit" id="submitknap" name="sendPhoto" value="Send billede" />
        </div>

      </div>
		</form>
<?php
}

function displayThanks() {
?>
    <h3>Tak!</h3>
    <p>Nu er du med i konkurrencen<?php if ( $_POST["visitorName"] ) echo ", " . $_POST["visitorName"] ?>!</p>
    <p>Deltagere:</p>
   
<?php
}
?>

    	

        <div id="article_list">
			<?php
			// find files in folder  and sort by filename
			$allFiles = scandir($sti,1);
			sort($allFiles);
			// and show them BUT only if they are jpg
			$howMany = count($allFiles);
			for($i=0;$i<$howMany;$i++){
				if (".jpg"==substr($allFiles[$i],-4)) {
				echo "
				<article class='show' onClick=\" swop(this) \">		
					<img src=\"$sti/$allFiles[$i]\" />
					<div class='cover' onClick=\" swop2(this) \"></div>
				</article>	";
				} else {
					echo("<!-- ".$allFiles[$i]."-->");
				}
			}
			?>
        </div>
    	
    	
    	
    	
    </section>
    
    
</body>
</html>
   		
        </div>
    </body>
</html>