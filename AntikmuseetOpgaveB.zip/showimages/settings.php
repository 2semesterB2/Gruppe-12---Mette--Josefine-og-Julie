<?php 
	$title = "My favourite movies";
	$sti = $_SERVER['DOCUMENT_ROOT'].'/yourfoldernamehere/Pics/small';
	$sti = "./blomster"; // delete this line if your PHP 
					//  requires more specific folder id (as in line 3)
	
?>