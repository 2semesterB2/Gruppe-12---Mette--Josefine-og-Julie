// JavaScript Document

$(document).ready(function(){
	
	var obj = document.createElement("audio");
	obj.src="audio/tempel.mp3";
	obj.autoPlay=true;
	
	var skrig = document.createElement("audio");
	skrig.src="audio/skrig.mp3";
	skrig.autoPlay=true;
	
	var knage = document.createElement("audio");
	knage.src="audio/knage.mp3";
	knage.autoPlay=true;
	
	var tabast = document.createElement("audio");
	tabast.src="audio/tabast.m4a";
	tabast.autoPlay=true;
	
	$("#tempel").click(function(){
		$("#tempeltekst").css({opacity: 0, visibility: "visible"}).animate({opacity: 1.0},800);
		$("#tabasttekst").css("visibility","hidden");
		$("#stikmantekst").css("visibility", "hidden");
		$("#kistetekst").css("visibility","hidden");
		obj.currentTime=0;
		obj.play();
		skrig.pause();
		knage.pause();
		tabast.pause();
	});
	
	$("#tabast").click(function(){
		$("#tempeltekst").css("visibility","hidden");
		$("#tabasttekst").css({opacity: 0, visibility: "visible"}).animate({opacity: 1.0},800);
		$("#stikmantekst").css("visibility", "hidden");
		$("#kistetekst").css("visibility","hidden");
		tabast.currentTime=0;
		obj.pause();
		skrig.pause();
		knage.pause();
		tabast.play();
	});
	
	$("#stikman").click(function(){
		$("#tempeltekst").css("visibility","hidden");
		$("#tabasttekst").css("visibility","hidden");
		$("#stikmantekst").css({opacity: 0, visibility: "visible"}).animate({opacity: 1.0},800);
		$("#kistetekst").css("visibility","hidden");
		skrig.currentTime=0;
		obj.pause();
		skrig.play();
		knage.pause();
		tabast.pause();
	});
	
	$("#kiste").click(function(){
		$("#tempeltekst").css("visibility","hidden");
		$("#tabasttekst").css("visibility","hidden");
		$("#stikmantekst").css("visibility", "hidden");
		$("#kistetekst").css({opacity: 0, visibility: "visible"}).animate({opacity: 1.0},800);
		knage.currentTime=0;
		obj.pause();
		skrig.pause();
		knage.play();
		tabast.pause();
	});
	

});

